#include "vaccine.h"
#include<iostream>
#include<chrono>
#include<ctime>
#include<stdio.h>//standard input output
#include<fstream>
#include<conio.h>//console input output
#include<string>
#include<sstream>
#include<windows.h> //for sleep
#include<iomanip>//manipulate the output of C++
#include<time.h>//manipulte date and time info
#define num_of_vaccine 0
using namespace std;

void menu();
void show();

// struct Date
// {
//     int day,month,year;
// };

// const int monthDays[12]  //to store Number of days in all months from Jan to Dec.
//     = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    
// int CountLeapYears(Date day)
//  {                          

// int years=day.year;
   
//     if (day.month <= 2)
//     {
//         years--;
//     }
   
//     return years / 4
//            - years / 100
//            + years / 400;

// }  
 
// int getDifference(Date date1,Date date2)//to get the difference between two dates

// {
    
//     long int number1=date1.year*365+date1.day;
//     for (int iterator = 0; iterator < date1.month - 1; iterator++)
//     {
//         number1 += monthDays[iterator];
//     number1 += CountLeapYears(date1);
//     }
//     long int number2 = date2.year * 365 + date2.day;
//     for (int iterator = 0; iterator < date2.month - 1; iterator++)
//     {   
//     number2 += monthDays[iterator];
//     number2 += CountLeapYears(date2);  
//     }
//     return (number2 - number1);
// }
template <class Int>
constexpr
Int
days_from_civil(Int y, unsigned m, unsigned d) noexcept
{
    static_assert(std::numeric_limits<unsigned>::digits >= 18,
             "This algorithm has not been ported to a 16 bit unsigned integer");
    static_assert(std::numeric_limits<Int>::digits >= 20,
             "This algorithm has not been ported to a 16 bit signed integer");
    y -= m <= 2;
    const Int era = (y >= 0 ? y : y-399) / 400;
    const unsigned yoe = static_cast<unsigned>(y - era * 400);      // [0, 399]
    const unsigned doy = (153*(m > 2 ? m-3 : m+9) + 2)/5 + d-1;  // [0, 365]
    const unsigned doe = yoe * 365 + yoe/4 - yoe/100 + doy;         // [0, 146096]
    return era * 146097 + static_cast<Int>(doe) - 719468;
}
bool Vaccine :: check() // to check the number of vaccines before adding records

{
    ifstream file_obj;
    int iterator=0;
    bool IsTrue=true;
    file_obj.open("vaccinetrial.txt");
    file_obj.seekg(0,ios :: beg);

    while(file_obj.read((char*)this,sizeof(Vaccine)))
    {
        iterator++;

    }
    file_obj.close();
     int sum=num_of_vaccine-iterator;
    int f_var=0;//file variable
    fstream file;
    file.open("count.txt",ios::in);
    file>>f_var;
    if((f_var+sum)<=0)
    {
        cout<<"WARNIG!!!!,insufficient vaccine,add vaccine"<<endl;
        getch();
        IsTrue=false;
        Vaccine::viewVaccine();
    }
    getch();
    file_obj.close();
    return IsTrue;
}

void Vaccine :: pin_c(char[])
        {
         gets(pin);      
        if(strlen(pin)<6 || strlen(pin)>6)
        {
            cout<<"Enter a valid Pincode";
            pin_c(pin);
        }
        }

void Vaccine::setData() // to take read the user inputs

{
    system("cls");
    cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
    cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
	cout<<"\t\t\t\t\t\t\t "<<endl;
    cout<<"\n\t\t\t*****************************************\n";
    cout<<"\t\t\t\t ENTER THE DETAILS ";
    cout<<"\n\t\t\t*****************************************\n\n";
    
        fflush(stdin);
        fflush(stdin);
        cout<<"\n\t\t Enter your Mobile number :- ";        
        gets(mobileNumber);
        dose_check(mobileNumber,dose);
        cout<<"\n\t\t Enter your name :-  ";
        gets(name);
        fflush(stdin);
        cout<<"\n\t\t getting  date :- ";
        int dot =5;while(dot>0){dot--;cout<<".";Sleep(250);}
        datec();
        fflush(stdin);
        cout<<"\n\t\t Enter the vaccine injected :- ";
        gets(vaccine);
        cout<<"\n\t\t Enter Pincode :-  ";
        pin_c(pin);
        
}
char Vaccine::dose_check(char[],char)
{
int count=0;    
if(strlen(mobileNumber)<10 || strlen(mobileNumber)>10)
        {
            cout<<"Enter a valid phone number";
            dose_check(mobileNumber,dose);
        }
        fflush(stdin);

        if (dose == '1')
        {
        char Mob_cpy[100];
        strcpy(Mob_cpy,mobileNumber);
        ifstream file_object;
        file_object.open("vaccinetrial.txt");

        while(!file_object.eof())
        {
            if(file_object.read(reinterpret_cast<char*>(this),sizeof(*this)))
            {
                if(strcmp(Mob_cpy,mobileNumber)==0)
                {
                    cout<<"\n\t\t Number found in records ,enter another mobile number\n";
                    Vaccine :: setData();
                }
            }
                strcpy(mobileNumber,Mob_cpy);
                file_object.close();
        }
        }

        if (dose == '2')
        {
        int temp; 
        char Mob_cpy[100];
        strcpy(Mob_cpy,mobileNumber);
        ifstream file_object;
        file_object.open("vaccinetrial.txt");
        file_object.seekg(0,ios::beg);
        while(!file_object.eof())
        {
        if(file_object.read(reinterpret_cast<char*>(this),sizeof(*this)))
        {

            if(strcmp(Mob_cpy,mobileNumber)==0)
            {
                count++;
            }    
        }
        }
            strcpy(mobileNumber,Mob_cpy);
            dose='2';
            file_object.close();
        }
        
         if(count>1)
            {
                    cout<<"This phone number is found more than twice";
                    getch();
                    Vaccine :: setData();
            }
return 0;
}

void Vaccine::addNew() // adding new records which are taken from setData()

{
    long sum;
    cout<<"\nEnter dose\n";
    cin>>dose;
    if(dose=='1')
    {
        writex();
    }
    else if (dose=='2')
    {
    cout<<"\nenter date of first Vaccination(in DD-MM-YYYY format)\n";
    cout<<"enter day: ";
    cin>>day1;
    cout<<"\nenter month: ";
    cin>>month1;
    cout<<"\nenter year: ";
    cin>>year1;
    cout<<"\nGetting today's date\n";
    for(int i=0;i<6;i++){cout<<".";Sleep(250);}
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    std::string tmp = std::to_string(day2) +"/";
     cout<<tm.tm_mday<<"/"<<tm.tm_mon +1<<"/"<<tm.tm_year + 1900;
    // Date date1 = {day1,month1,year1};
    // Date date2 = {(tm.tm_mday),(tm.tm_mon +1),(tm.tm_year + 1900)};
    sum = days_from_civil(tm.tm_year+1900,tm.tm_mon+1, tm.tm_mday)- days_from_civil(year1,month1,day1) ;
    // Function call
        if (sum>60)
        {
            writex();
        }
        else
        {
        cout<<"\n Wait for "<<60-sum<<" days before next dose\n";
        return;
    }
    }
}
void Vaccine :: writex()
{
    fstream outin;
    outin.open("vaccinetrial.txt",ios::app|ios::out);
    setData();
    outin.write((char*)this,sizeof(Vaccine));
    cout<<"YOUR DATA HAS BEEN SUCCESSFULLY INSERTED "<<endl;
    getch();
    outin.close();
    menu();
}
 
void Vaccine::showList()// prints data 
{
    cout<<"\n";
    cout<<setw(15)<<setiosflags(ios::left)<<mobileNumber;
    cout<<setw(15)<<name;
    cout<<setw(15)<<pin;
    cout<<setw(15)<<vaccine;
    cout<<setw(15)<<dose;    
    cout<<setw(15)<<fputs(date, stdout);
    cout<<endl;
}
void Vaccine::view_by_pin() // number of vaccines are distributed in a particular data
{

    ifstream file_object;
	file_object.open("vaccinetrial.txt");
    int count=0;
    char checkNumber[10];
    cout<<"enter pincode"<<endl;
    getch();
    fflush(stdin);
    gets(checkNumber);
       while(!file_object.eof())
	{
	if(file_object.read(reinterpret_cast<char*>(this),sizeof(*this))){

        if(strcmp(checkNumber,pin)==0)
        {
            count++;
        }
		}
    }
    cout<<"the number of people vaccinated is :"<<endl;
    cout<<count;
    file_object.close();
    getch();
    }

void Vaccine ::viewVaccine()// to get the details of vaccine including adding more vaccines
{
    ifstream file_object;
    int incrementor=0;
    file_object.open("vaccinetrial.txt");
    file_object.seekg(0,ios::beg);
    while(file_object.read((char*)this,sizeof(Vaccine)))
    {
        incrementor++;
    }
    file_object.close();
    int choice;
    int s=num_of_vaccine-incrementor;
    system("cls");
    cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
    cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
	cout<<"\t\t\t\t\t\t\t "<<endl;
    cout<<"\n\t\t\t*****************************************\n";
    cout<<"\t\t\t\tVACCINE STATISTICS";
    cout<<"\n\t\t\t*****************************************\n\n";
    cout<<"\t\t 1. Add more        \t\t\t2.View available \n\t\t\t\t\t 3. Back"<<endl;
    cin>>choice;
    int f_var=0;//file variable
    fstream file("count.txt",ios::in);
    file>>f_var;
    file.close();
    switch(choice)
    {
    case 1:
        int vaccine_number;
        cout<<"\t Enter number of vaccines you want to add :"<<endl;
        cin>>vaccine_number;
        f_var=f_var+vaccine_number;
        file.open("count.txt",ios::out);
        file.seekg(0);
        file<<f_var;
        cout<<"\t\t Now total number of vaccines are : "<<f_var+s;
        file.close();
        getch();
        viewVaccine();
        break;
    case 2:
    	file.open("count.txt",ios::in);
        cout<<"\n\nAvailable number of vaccines are : "<<s+f_var;
        file.close();
        getch();
        viewVaccine();
        break;
    case 3:
        system("cls");
        menu();
    default:
        system("cls");
        cout<<"\nEnter valid option "<<endl;
        menu();
    }
    file.close();
    getch();
}


void Vaccine::searchData() // searching datas 
{
    int option;
    system("cls");
    cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
    cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
	cout<<"\t\t\t\t\t\t\t "<<endl;
    cout<<"\n\t\t\t*****************************************\n";
    cout<<"\t\t\t\tChoose Option:";
    cout<<"\n1.Search by Name\n2.Search by Mobile\n3.Search by Vaccine\n4.Back"<<endl;
    fflush(stdin);
    cin>>option;
    
    switch(option)
    {
        case 1:system("cls");
                Search_by_Name();
                searchData();
                break;
        case 2:system("cls");
                search_by_mobile();
                searchData();                
                break;
        case 3: system("cls");
                search_by_vaccine();
                searchData();
                break;
        case 4: system("cls");
                menu();
                break;
    }
        getch();
}


void Vaccine::search_by_mobile()// showing datas based on phone number
{
    ifstream file_object;
	file_object.open("vaccinetrial.txt");
    bool flag =false;
    int count=0;
    char Mob_num[100];
    cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
    cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
	cout<<"\t\t\t\t\t\t\t "<<endl;
    cout<<"\n\t\t\t*****************************************\n";
    cout<<"\n\t\t\t*****************************************\n\n";
    cout<<"Enter mobile number to search: "<<endl;
    fflush(stdin);
    gets(Mob_num);
    show();
    
    while(!file_object.eof())
	{
	if(file_object.read(reinterpret_cast<char*>(this),sizeof(*this))){

        if(strcmp(Mob_num,mobileNumber)==0)
        {
            showList();
            flag=true;    
        }
        }
    }
    if(flag==false)
    {
    cout<<"SORRY!!This Mobile is not found in records."<<endl;
    }

        file_object.close();
        getch();

}


void Vaccine :: Search_by_Name() //showing datas based on names
{

    fstream file_object;
    file_object.open("vaccinetrial.txt");
    bool flag=false;
    char Search_name[100];
    cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
    cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
	cout<<"\t\t\t\t\t\t\t "<<endl;
    cout<<"\n\t\t\t*****************************************\n";
    cout<<"\n\t\t\t*****************************************\n\n";
    cout<<"Enter  Name  to search: "<<endl;
    fflush(stdin);
    gets(Search_name);
    show();

    while(!file_object.eof())
    {
        if(file_object.read(reinterpret_cast<char*>(this),sizeof(*this)))
        {
            if(strcmp(Search_name,name)==0)
            {
                showList();
                flag=true;
                
            }
        }
}
if(flag==false)
{
    cout<<"Sorry This Name Is not find in records!!!..."<<endl;
}

file_object.close();
getch();
}


void Vaccine :: search_by_vaccine() // to get the list of 
{
    char Vacc_Name[100];
    bool flag=false;
    int count=0;
    fstream vac;
    vac.open("vaccinetrial.txt");
    cout<<endl;
    cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
    cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
	cout<<"\t\t\t\t\t\t\t "<<endl;
    cout<<"\n\t\t\t*****************************************\n";
    cout<<"\t\t\t\t\t"<<"   MAIN MENU"<<endl;
    cout<<"\n\t\t\t*****************************************\n\n";
    cout<<"Enter  Vaccine to Search: "<<endl;
    fflush(stdin);
    gets(Vacc_Name);
    show();
    
    while(!vac.eof())
    {
        if(vac.read(reinterpret_cast<char*>(this),sizeof(*this)))
        {
            if(strcmp(Vacc_Name,vaccine)==0)
            {
                showList();
                flag=true;
                count++;
            }
    }    
}
if(flag==false)
{
    cout<<"No Records Found"<<endl;
}
cout<<"\n\n\n No of people vaccinated by this vaccine: "<<count<<endl;
    vac.close();
getch();
}

void Vaccine::view_all() // view all records of vaccination
{
			fstream file_object;
			file_object.open("vaccinetrial.txt",ios::binary|ios::in);
			if(!file_object)
            {
				cout<<"File doesnot exist\n";
                Sleep(125);
				return;
			}
			else
            {
                cout<<endl;
                cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
                cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
                cout<<"\t\t\t\t\t\t\t "<<endl;
                cout<<"\n\t\t\t*****************************************\n";
                cout<<"\t\t\t\t\tALL DATA ";
                cout<<"\n\t\t\t*****************************************\n\n";
                show();
			while(!file_object.eof())
            {
				if(file_object.read(reinterpret_cast<char*>(this),sizeof(*this)))
                {
					showList();
				}
			}
			file_object.close();
			getch();
            }
}


void show() // shows data discription
{
	cout<<"\n\n\n";
    cout<<setw(15)<<setiosflags(ios::left)<<"Mobile No.";
    cout<<setw(15)<<"Name ";
    cout<<setw(15)<<"Pincode";
    cout<<setw(15)<<"Vaccine";
    cout<<setw(15)<<"Dose";
    cout<<setw(15)<<"Date"<<endl;
    cout<<"-----------------------------------------------------------------------------------\n";
}


void menu()// displays menu
{
    system("cls");
    cout<<endl;
    cout<<"\t\t\t\t\t"<<"     VACCINE"<<endl;
    cout<<"\t\t\t\t\t"<<"MANAGEMENT SYSTEM "<<endl;
	cout<<"\t\t\t\t\t\t\t "<<endl;
    cout<<"\t\t\t\t"<<"==================================\n";
    cout<<"\t\t\t\t\t"<<"   MAIN MENU"<<endl;
    cout<<"\t\t\t\t"<<"==================================\n";
    cout<<"\n\t\t1: Add NEW Record\t\t\t 2: Add/View VACCINE DATA"<<endl;
    cout<<"\n\t\t3: search   \t\t\t\t 4: View All Data"<<endl;
    cout<<"\n\t\t5: View Vaccine by Pincode"<<"\t\t"<<" 6: Exit"<<endl;
    return;
}

void Vaccine :: datec()
 { 
  stringstream ss;
  stringstream sn;
  stringstream sp;
  time_t t = time(NULL);
  struct tm tm = *localtime(&t);
  string YEAR;
  ss<<tm.tm_year + 1900;
  ss>>YEAR;
  string MONTH ;
  sn<<tm.tm_mon +1;
  sn>>MONTH;
  string Day;
   sp<<tm.tm_mday;
   sp>>Day;
   Vaccine vobj;
   string date2 = (Day+"/"+MONTH+"/"+YEAR); 
   date2.copy(date,sizeof(date));
   cout<<date2;
}